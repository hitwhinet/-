<?php
header('Location: login_l.php');
exit;
